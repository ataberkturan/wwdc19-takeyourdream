//WWDC 2019
//Think Different

import UIKit
import PlaygroundSupport
import AVFoundation


//UIView Convert to UIImage
extension UIImage{
    convenience init(view: UIView){
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.isOpaque, 0.0)
        view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        self.init(cgImage: (image?.cgImage)!)
    }
}
//End


public var day = Int()
public var nameImage = UIImage()
public var hideImageVisibility = Bool()

public class detailsVC : UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //Objects
    let backImage = UIImageView(image: UIImage(named: "images/detailsView/background.png"))
    let logoImage = UIImageView(image: UIImage(named: "images/homepage/logo.png"))
    let targetBodyImage = UIImageView(image: UIImage(named: "images/detailsView/targetAmount-body.png"))
    let currentBodyImage = UIImageView(image: UIImage(named: "images/detailsView/currentMoney-body.png"))
    let targetHeaderImage = UIImageView(image: UIImage(named: "images/detailsView/targetAndcurrent-header.png"))
    let currentHeaderImage =  UIImageView(image: UIImage(named: "images/detailsView/targetAndcurrent-header.png"))
    let pictureofdreamImage = UIImageView(image: UIImage(named: "images/detailsView/PICTUREOFDREAMtext.png"))
    let targetamountImage = UIImageView(image: UIImage(named: "images/detailsView/TARGETAMOUNTtext"))
    let currentmoneyImage = UIImageView(image: UIImage(named: "images/detailsView/CURRENTMONEYtext"))
    let plusminusBack = UIImageView(image: UIImage(named: "images/detailsView/minusAndplusBackground.png"))
    let sizeBack = UIImageView(image: UIImage(named: "images/drawingView/sizeBackground.png"))
    let plusButton = UIButton()
    let minusButton = UIButton()
    let plusFiveButton = UIButton()
    let minusFiveButton = UIButton()
    let currentCountText = UILabel()
    let targetAmountText = UILabel()
    let CanvasView = drawingView()
    let hideImageView = UIImageView()
    let backButton = UIButton()
    let deleteButton = UIButton()
    let color1Button = UIButton()
    let color2Button = UIButton()
    let color3Button = UIButton()
    let color4Button = UIButton()
    let size5Button = UIButton()
    let size15Button = UIButton()
    let clearButton = UIButton()
    let congratulationsLabel = UILabel()
    //End
    
    var buttonCount = Bool()
    var targetAmountCount = 0
    var currentMoneyCount  = 0
    var isActive = Bool()
    var audioPlayer = AVAudioPlayer()
    
    //func congratulationsAnimate()
    var animator : UIDynamicAnimator?
    var timer = Timer()
    var seconds = 40
    //End

    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let view = UIView()
        view.backgroundColor = UIColor(red:0.94, green:0.94, blue:0.96, alpha:1.0)
        self.view = view
        
        //Audio Player
            let path = Bundle.main.path(forResource: "Sounds/coin-sound", ofType: "mp3")
            
            do{
                audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path!))
            }catch{
                //error
            }
        //End
        
        //Saved Data Retrievals
        //Hide Image View Visibility
        if hideImageVisibility == true{
            CanvasView.isHidden = true
            let document = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let imageURL = document.appendingPathComponent("drawingImage.png", isDirectory: true)
            hideImageView.image = UIImage(contentsOfFile: imageURL.path)
            hideImageView.isHidden = false
        }else{
            hideImageView.isHidden = true
            CanvasView.isHidden = false
        }
        if let savedTarget = UserDefaults.standard.object(forKey: "target") as? Int{
            targetAmountCount = savedTarget
        }
        if let savedCurrent = UserDefaults.standard.object(forKey: "current") as? Int{
            currentMoneyCount = savedCurrent
        }
        //End
        
        //'Login Status' Control Point
        if loginStatus == true{
            backImage.frame = CGRect(x: 1, y: 45, width: 375, height: 308)
            color1Button.isHidden = true
            color2Button.isHidden = true
            color3Button.isHidden = true
            color4Button.isHidden = true
            size5Button.isHidden = true
            size15Button.isHidden = true
            clearButton.isHidden = true
            sizeBack.isHidden = true
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "target amount \(targetAmountCount) dollar current money \(currentMoneyCount) dollar")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.01
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
            
        }else{
            backImage.frame = CGRect(x: 1, y: 45, width: 375, height: 335)
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "draw a picture of your dream product")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.1
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
        }
        //End
        
        //Background Image
        backImage.contentMode = .bottom
        //End
        
        //Back Button
        backButton.setImage(UIImage(named: "images/detailsView/backButton.png"), for: .normal)
        backButton.frame = CGRect(x: 327, y: 23, width: 29, height: 29)
        backButton.addTarget(self, action: #selector(detailsVC.backButtonAction), for: .touchUpInside)
        //End
        
        //Delete Button
        deleteButton.setImage(UIImage(named: "images/detailsView/deleteButton.png"), for: UIControl.State.normal)
        deleteButton.frame = CGRect(x: 293, y: 23, width: 29, height: 29)
        deleteButton.addTarget(self, action: #selector(detailsVC.deleteAction), for: .touchUpInside)
        //End
        
        //Logo
        logoImage.contentMode = .bottom
        logoImage.frame = CGRect(x: 20, y: 12, width: 240, height: 56)
        //End
        
        //Drawing View
        CanvasView.frame = CGRect(x: 20, y: 77, width: 336, height: 207)
        CanvasView.layer.cornerRadius = 30
        CanvasView.backgroundColor = UIColor.white
        //End
        
        //Hide Image View
        hideImageView.frame = CGRect(x: 20, y: 77, width: 336, height: 207)
        hideImageView.layer.masksToBounds = true
        hideImageView.layer.cornerRadius = 30
        //End
        
        //Drawing View Pallets
            //Color 1 Pallet
            color1Button.setImage(UIImage(named: "images/drawingView/color1.png"), for: .normal)
            color1Button.frame = CGRect(x: 42, y: 295, width: 29, height: 29)
            color1Button.addTarget(self, action: #selector(detailsVC.color1Pallet), for: .touchUpInside)
            //Color 2 Pallet
            color2Button.setImage(UIImage(named: "images/drawingView/color2.png"), for: .normal)
            color2Button.frame = CGRect(x: 86, y: 295, width: 29, height: 29)
            color2Button.addTarget(self, action: #selector(detailsVC.color2Pallet), for: .touchUpInside)
            //Color 3 Pallet
            color3Button.setImage(UIImage(named: "images/drawingView/color3.png"), for: .normal)
            color3Button.frame = CGRect(x: 130, y: 295, width: 29, height: 29)
            color3Button.addTarget(self, action: #selector(detailsVC.color3Pallet), for: .touchUpInside)
            //Color 4 Pallet
            color4Button.setImage(UIImage(named: "images/drawingView/color4.png"), for: .normal)
            color4Button.frame = CGRect(x: 174, y: 295, width: 29, height: 29)
            color4Button.addTarget(self, action: #selector(detailsVC.color4Pallet), for: .touchUpInside)
            //Size Settings Background Image
            sizeBack.contentMode = .bottom
            sizeBack.frame = CGRect(x: 218, y: 306, width: 116, height: 29.5)
            //Size 5 Button
            size5Button.setImage(UIImage(named: "images/drawingView/size5.png"), for: .normal)
            size5Button.frame = CGRect(x: 261, y: 299, width: 10, height: 18)
            size5Button.addTarget(self, action: #selector(detailsVC.size5Pallet), for: .touchUpInside)
            //Size 15 Button
            size15Button.setImage(UIImage(named: "images/drawingView/size15.png"), for: .normal)
            size15Button.frame = CGRect(x: 276, y: 299, width: 14, height: 18)
            size15Button.addTarget(self, action: #selector(detailsVC.size15Pallet), for: .touchUpInside)
            //Clear Button
            clearButton.setImage(UIImage(named: "images/drawingView/clearButton.png"), for: .normal)
            clearButton.frame = CGRect(x: 298, y: 303, width: 24, height: 12)
            clearButton.addTarget(self, action: #selector(detailsVC.clearDrawing), for: .touchUpInside)
        //End
        
        
        
        
        //Target Amount - Body
            //Background
            targetBodyImage.contentMode = .bottom
            targetBodyImage.frame = CGRect(x: 11, y: 414, width: 170, height: 177.5)
            targetBodyImage.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(detailsVC.targetGesture))
            targetBodyImage.addGestureRecognizer(tapGesture)
        
        
            //Count Text
            targetAmountText.text = "$\(targetAmountCount)"
            targetAmountText.textColor = UIColor.white
            targetAmountText.textAlignment = .center
            targetAmountText.font = UIFont(name: "Avenir-Black", size: 30)
            targetAmountText.frame = CGRect(x: 12, y: 494, width: 170, height: 30)
        //End
        
        //Current Money - Body
            //Background
            currentBodyImage.contentMode = .bottom
            currentBodyImage.frame = CGRect(x: 194, y: 414, width: 170, height: 177.5)
            currentBodyImage.isUserInteractionEnabled = true
            let tapGesture2 = UITapGestureRecognizer(target: self, action: #selector(detailsVC.currentGesture))
            currentBodyImage.addGestureRecognizer(tapGesture2)
        
            //Count Text
            currentCountText.text = "$\(currentMoneyCount)"
            currentCountText.textColor = UIColor.white
            currentCountText.textAlignment = .center
            currentCountText.font = UIFont(name: "Avenir-Black", size: 30)
            currentCountText.frame = CGRect(x: 195, y: 494, width: 170, height: 30)
        //End
        
        //Target Amount - Header
        targetHeaderImage.contentMode = .bottom
        targetHeaderImage.frame = CGRect(x: 11, y: 405, width: 170, height: 58.5)
        //End
        
        //Current Money - Header
        currentHeaderImage.contentMode = .bottom
        currentHeaderImage.frame = CGRect(x: 194, y: 405, width: 170, height: 58.5)
        //End
        
        //TARGETAMOUNT Text
        targetamountImage.contentMode = .bottom
        targetamountImage.frame = CGRect(x: 27, y: 414, width: 136, height: 15)
        //End
        
        //CURRENTMONEY Text
        currentmoneyImage.contentMode = .bottom
        currentmoneyImage.frame = CGRect(x: 209, y: 414, width: 138, height: 15)
        //End
        
        // Plus and Minus Button Background
        plusminusBack.contentMode = .bottom
        plusminusBack.frame = CGRect(x: 87, y: 603, width: 202, height: 62.5)
        plusminusBack.isHidden = true
        //End
        
        // Plus, Minus, Plus Five and Minus Five Button
            //Plus
            plusButton.setImage(UIImage(named: "images/detailsView/plusButton.png"), for: .normal)
            plusButton.frame = CGRect(x: 135, y: 598, width: 62, height: 62)
            plusButton.isHidden = true
            plusButton.addTarget(self, action: #selector(detailsVC.plusButtonAction), for: .touchUpInside)
        
            //Minus
            minusButton.setImage(UIImage(named: "images/detailsView/minusButton.png"), for: .normal)
            minusButton.frame = CGRect(x: 188, y: 567, width: 62, height: 112)
            minusButton.isHidden = true
            minusButton.addTarget(self, action: #selector(detailsVC.minusButtonAction), for: .touchUpInside)
        
            //Plus Five
            plusFiveButton.setImage(UIImage(named: "images/detailsView/plusFiveButton.png"), for: .normal)
            plusFiveButton.frame = CGRect(x: 93, y: 598, width: 62, height: 62)
            plusFiveButton.isHidden = true
            plusFiveButton.addTarget(self, action: #selector(detailsVC.plusFiveButtonAction), for: .touchUpInside)
        
            //Minus Five
            minusFiveButton.setImage(UIImage(named: "images/detailsView/minusFiveButton.png"), for: .normal)
            minusFiveButton.frame = CGRect(x: 230, y: 598, width: 62, height: 62)
            minusFiveButton.isHidden = true
        minusFiveButton.addTarget(self, action: #selector(detailsVC.minusFiveButtonAction), for: .touchUpInside)
        //End
        
        //Add Subview
        view.addSubview(backImage)
        view.addSubview(backButton)
        view.addSubview(logoImage)
        view.addSubview(targetBodyImage)
        view.addSubview(currentBodyImage)
        view.addSubview(targetHeaderImage)
        view.addSubview(currentHeaderImage)
        view.addSubview(deleteButton)
        view.addSubview(targetamountImage)
        view.addSubview(currentmoneyImage)
        view.addSubview(plusminusBack)
        view.addSubview(minusButton)
        view.addSubview(plusButton)
        view.addSubview(plusFiveButton)
        view.addSubview(minusFiveButton)
        view.addSubview(currentCountText)
        view.addSubview(targetAmountText)
        view.addSubview(CanvasView)
        view.addSubview(hideImageView)
        view.addSubview(color1Button)
        view.addSubview(color2Button)
        view.addSubview(color3Button)
        view.addSubview(color4Button)
        view.addSubview(sizeBack)
        view.addSubview(size5Button)
        view.addSubview(size15Button)
        view.addSubview(clearButton)
        //End
        
        //Animations func
        backgroundAnimate()
    }
    
    
    @objc func backButtonAction(){
        if targetAmountCount == 0{
            
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "target amount is empty")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.02
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
            
            let alert = UIAlertController(title: "Empty", message: "'Target Amount' is empty!", preferredStyle: .alert)
            let alertButton = UIAlertAction(title: "OK 😔", style: .cancel, handler: nil)
            alert.addAction(alertButton)
            self.present(alert, animated: true, completion: nil)
            
        }else{
            
            let drawingImage = UIImage.init(view: CanvasView)
            let document = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let imageURL = document.appendingPathComponent("drawingImage.png", isDirectory: true)
            if !FileManager.default.fileExists(atPath: imageURL.path){
                do{
                    try drawingImage.pngData()?.write(to: imageURL)
                    
                }catch{
                    print("image not added")
                }
            }
            
            if currentMoneyCount == UserDefaults.standard.object(forKey: "current") as? Int && targetAmountCount == UserDefaults.standard.object(forKey: "target") as? Int{
                
                PlaygroundPage.current.liveView = homepageVC()
                
            }else if currentMoneyCount != UserDefaults.standard.object(forKey: "current") as? Int && targetAmountCount == UserDefaults.standard.object(forKey: "target") as? Int{
                
                UserDefaults.standard.set(currentMoneyCount, forKey: "current")
                
            }else if  currentMoneyCount == UserDefaults.standard.object(forKey: "current") as? Int && targetAmountCount != UserDefaults.standard.object(forKey: "target") as? Int{
                
                UserDefaults.standard.set(targetAmountCount, forKey: "target")
            }else{
                UserDefaults.standard.set(targetAmountCount, forKey: "target")
                UserDefaults.standard.set(currentMoneyCount, forKey: "current")
                
            }
               UserDefaults.standard.synchronize()
            if let day = UserDefaults.standard.object(forKey: "target") as? Int{
                if let currentMoney = UserDefaults.standard.object(forKey: "current") as? Int{
                    daysLabel.text = String((day - currentMoney)/5)
                    if daysLabel.text == "0"{
                        daysLabel.text = "1"
                    }
                }
            }
               PlaygroundPage.current.liveView = homepageVC()
        }
    }
    
    @objc func deleteAction(){
        if (UserDefaults.standard.object(forKey: "name") as? NSData) != nil{
            UserDefaults.standard.removeObject(forKey: "name")
            UserDefaults.standard.synchronize()
        }
        if (UserDefaults.standard.object(forKey: "target") as? Int) != nil{
            UserDefaults.standard.removeObject(forKey: "target")
            UserDefaults.standard.synchronize()
            targetAmountCount = 0
        }
        if (UserDefaults.standard.object(forKey: "current") as? Int) != nil{
            UserDefaults.standard.removeObject(forKey: "current")
            UserDefaults.standard.synchronize()
            currentMoneyCount = 0
        }
        
        let document = FileManager.default
        let path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("drawingImage.png")
        if document.fileExists(atPath: path){
            try! document.removeItem(atPath: path)
        }else{
            
        }
        loginStatus = false
        //Text to Speech
        let utterance = AVSpeechUtterance(string: "all data deleted")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
        utterance.rate = 0.2
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
        //End
        PlaygroundPage.current.liveView = getNameViewVC()
    }
    
    
    
    //Drawing View
    @objc func clearDrawing(){
        CanvasView.clearCanvas()
    }
    @objc func color1Pallet(){
        CanvasView.color1Button()
    }
    @objc func color2Pallet(){
        CanvasView.color2Button()
    }
    @objc func color3Pallet(){
        CanvasView.color3Button()
    }
    @objc func color4Pallet(){
        CanvasView.color4Button()
    }
    @objc func size5Pallet(){
        CanvasView.size5Button()
    }
    @objc func size15Pallet(){
        CanvasView.size15Button()
    }
    //End
    
    
    
    @objc func targetGesture(){
        plusminusBack.isHidden = false
        plusButton.isHidden = false
        minusButton.isHidden = false
        plusFiveButton.isHidden = false
        minusFiveButton.isHidden = false
        plusandminusAnimate()
    
        if currentMoneyCount == targetAmountCount{
            plusButton.isEnabled = true
            minusButton.isEnabled = true
            plusFiveButton.isEnabled = true
            minusFiveButton.isEnabled = true
        }
        
        buttonCount = false
        if isActive == false{
            isActive = true
            plusminusBack.isHidden = false
            plusButton.isHidden = false
            minusButton.isHidden = false
            plusFiveButton.isHidden = false
            minusFiveButton.isHidden = false
            plusandminusAnimate()
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "Target Amount")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.01
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
        }else{
            isActive = false
            plusminusBack.isHidden = true
            plusButton.isHidden = true
            minusButton.isHidden = true
            plusFiveButton.isHidden = true
            minusFiveButton.isHidden = true
        }
    }
    
    @objc func currentGesture(){
        
        if targetAmountCount == 0 && currentMoneyCount == 0{
            plusButton.isEnabled = false
            minusButton.isEnabled = false
            plusFiveButton.isEnabled = false
            minusFiveButton.isEnabled = false
        }else{
            plusButton.isEnabled = true
            minusButton.isEnabled = true
            plusFiveButton.isEnabled = true
            minusFiveButton.isEnabled = true
        }
        
        if currentMoneyCount == targetAmountCount{
            plusButton.isEnabled = false
            plusFiveButton.isEnabled = false
        }else{
            plusButton.isEnabled = true
            plusFiveButton.isEnabled = true
        }
        
        buttonCount = true
        plusminusBack.isHidden = false
        plusButton.isHidden = false
        minusButton.isHidden = false
        plusFiveButton.isHidden = false
        minusFiveButton.isHidden = false
        plusandminusAnimate()

        if isActive == false{
            isActive = true
            plusminusBack.isHidden = false
            plusButton.isHidden = false
            minusButton.isHidden = false
            plusFiveButton.isHidden = false
            minusFiveButton.isHidden = false
            plusandminusAnimate()
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "Current Money")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.01
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
        }else{
            isActive = false
            plusminusBack.isHidden = true
            plusButton.isHidden = true
            minusButton.isHidden = true
            plusFiveButton.isHidden = true
            minusFiveButton.isHidden = true
        }
    }
    
    @objc func plusButtonAction(){
        if buttonCount == false{
            targetAmountCount += 1
            targetAmountText.text = "$\(targetAmountCount)"
            if targetAmountCount >= 1000000{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }else if targetAmountCount <= 0{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }
        }else{
            currentMoneyCount += 1
            currentCountText.text = "$\(currentMoneyCount)"
            audioPlayer.play()
            if currentMoneyCount == targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                currentMoneyCount = targetAmountCount
                currentCountText.text = "$\(currentMoneyCount)"
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= 1000000{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }else if currentMoneyCount <= 0{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }
        }
    }
    
    @objc func plusFiveButtonAction(){
        if buttonCount == false{
            targetAmountCount += 5
            targetAmountText.text = "$\(targetAmountCount)"
            if targetAmountCount >= 1000000{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }else if targetAmountCount <= 0{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }
        }else{
            currentMoneyCount += 5
            currentCountText.text = "$\(currentMoneyCount)"
            audioPlayer.play()
            if currentMoneyCount == targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                currentMoneyCount = targetAmountCount
                currentCountText.text = "$\(currentMoneyCount)"
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= 1000000{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }else if currentMoneyCount <= 0{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }
        }
    }
    
    @objc func minusButtonAction(){
        if buttonCount == false{
            targetAmountCount -= 1
            targetAmountText.text = "$\(targetAmountCount)"
            if targetAmountCount <= currentMoneyCount{
                currentMoneyCount = targetAmountCount
                if currentMoneyCount <= 0{
                    currentMoneyCount = 0
                }
                currentCountText.text = "$\(currentMoneyCount)"
            }
            if targetAmountCount >= 1000000{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }else if targetAmountCount <= 0{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }
        }else{
            currentMoneyCount -= 1
            currentCountText.text = "$\(currentMoneyCount)"
            if currentMoneyCount == targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                currentMoneyCount = targetAmountCount
                currentCountText.text = "$\(currentMoneyCount)"
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= 1000000{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }else if currentMoneyCount <= 0{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }
        }
    }
    
    @objc func minusFiveButtonAction(){
        if buttonCount == false{
            targetAmountCount -= 5
            targetAmountText.text = "$\(targetAmountCount)"
            if targetAmountCount <= currentMoneyCount{
                currentMoneyCount = targetAmountCount
                if currentMoneyCount <= 0{
                    currentMoneyCount = 0
                }
                currentCountText.text = "$\(currentMoneyCount)"
            }
            if targetAmountCount >= 1000000{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }else if targetAmountCount <= 0{
                targetAmountCount = 0
                targetAmountText.text = "$\(targetAmountCount)"
            }
        }else{
            currentMoneyCount -= 5
            currentCountText.text = "$\(currentMoneyCount)"
            if currentMoneyCount == targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= targetAmountCount{
                plusButton.isEnabled = false
                plusFiveButton.isEnabled = false
                currentMoneyCount = targetAmountCount
                currentCountText.text = "$\(currentMoneyCount)"
                congratulationsAnimate()
            }else{
                plusButton.isEnabled = true
                plusFiveButton.isEnabled = true
            }
            if currentMoneyCount >= 1000000{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }else if currentMoneyCount <= 0{
                currentMoneyCount = 0
                currentCountText.text = "$\(currentMoneyCount)"
            }
        }
    }
    
    //Plus And Minus Button Animate Func
    func plusandminusAnimate(){
        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0, 500, 0)
        self.plusminusBack.layer.transform = rotationTransform
        self.plusButton.layer.transform = rotationTransform
        self.minusButton.layer.transform = rotationTransform
        self.plusFiveButton.layer.transform = rotationTransform
        self.minusFiveButton.layer.transform = rotationTransform
        
        UIView.animate(withDuration: 0.5) {
            self.plusminusBack.layer.transform = CATransform3DIdentity
            self.plusButton.layer.transform = CATransform3DIdentity
            self.minusButton.layer.transform = CATransform3DIdentity
            self.plusFiveButton.layer.transform = CATransform3DIdentity
            self.minusFiveButton.layer.transform = CATransform3DIdentity
        }
    }
    
    //Congratulations Animate
    func congratulationsAnimate(){
        self.animator = UIDynamicAnimator(referenceView: self.view)
        let gravity = UIGravityBehavior(items: [CanvasView, size5Button, size15Button, clearButton, backImage, backButton, deleteButton, logoImage, targetBodyImage, currentBodyImage, targetHeaderImage, currentHeaderImage, currentCountText, targetAmountText, color1Button, color2Button, color3Button, color4Button, sizeBack, targetamountImage, currentmoneyImage, plusButton, minusButton, plusFiveButton, minusFiveButton, plusminusBack, hideImageView])
        self.animator!.addBehavior(gravity)
        
        //Label 1
        congratulationsLabel.textAlignment = .center
        congratulationsLabel.font = UIFont(name: "AvenirNextCondensed-Bold", size: 460)
        congratulationsLabel.frame = CGRect(x: 52, y: 19, width: 270, height: 630)
        congratulationsLabel.textColor = UIColor(red:0.94, green:0.63, blue:0.00, alpha:1.0)
        view.addSubview(congratulationsLabel)
        
        //Setting Timer
        timer = Timer.scheduledTimer(timeInterval: 0.2, target: self, selector: #selector(detailsVC.timerAction), userInfo: nil, repeats: true)
    }
    @objc func timerAction(){
        seconds -= 1
        if seconds == 38{
            congratulationsLabel.text = "C"
        }else if seconds == 36{
            congratulationsLabel.text = "O"
        }else if seconds == 34{
            congratulationsLabel.text = "N"
        }else if seconds == 32{
            congratulationsLabel.text = "G"
        }else if seconds == 30{
            congratulationsLabel.text = "R"
        }else if seconds == 28{
            congratulationsLabel.text = "A"
        }else if seconds == 26{
            congratulationsLabel.text = "T"
        }else if seconds == 24{
            congratulationsLabel.text = "U"
        }else if seconds == 22{
            congratulationsLabel.text = "L"
        }else if seconds == 20{
            congratulationsLabel.text = "A"
        }else if seconds == 18{
            congratulationsLabel.text = "T"
        }else if seconds == 16{
            congratulationsLabel.text = "I"
        }else if seconds == 14{
            congratulationsLabel.text = "O"
        }else if seconds == 12{
            congratulationsLabel.text = "N"
        }else if seconds == 10{
            congratulationsLabel.text = "S"
        }else if seconds == 8{
            
            congratulationsLabel.isHidden = true
            
            //End Label 2
            let congratulationsLabel2 = UILabel()
            congratulationsLabel2.textAlignment = .center
            congratulationsLabel2.textColor = UIColor(red:0.94, green:0.63, blue:0.00, alpha:1.0)
            congratulationsLabel2.frame = CGRect(x: 34, y: 297, width: 307, height: 55)
            congratulationsLabel2.text = "CONGRATULATIONS"
            congratulationsLabel2.font = UIFont(name: "AvenirNextCondensed-Bold", size: 40)
            view.addSubview(congratulationsLabel2)
            
            //End Label 2
            let descriptionLabel = UILabel()
            descriptionLabel.text = "You can buy your dream product now!"
            descriptionLabel.frame = CGRect(x: 37, y: 325, width: 304, height: 54)
            descriptionLabel.font = UIFont(name: "AvenirNextCondensed-Bold", size: 20)
            descriptionLabel.textColor = UIColor(red:0.13, green:0.14, blue:0.29, alpha:1.0)
            descriptionLabel.textAlignment = .center
            view.addSubview(descriptionLabel)
            
            //Text to Speech
            let utterance = AVSpeechUtterance(string: "CONGRATULATIONS you can buy your dream product now")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.2
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
            //End
            
            //Animations
            let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, -500, 0, 0)
            let rotationTransform2 = CATransform3DTranslate(CATransform3DIdentity, 500, 0, 0)
            
            //Congratulations Label Animate
            congratulationsLabel2.layer.transform = rotationTransform
            //Description Label Animate
            descriptionLabel.layer.transform = rotationTransform2
            
            UIView.animate(withDuration: 1.0) {
                congratulationsLabel2.layer.transform = CATransform3DIdentity
            }
            UIView.animate(withDuration: 1.5) {
                descriptionLabel.layer.transform = CATransform3DIdentity
            }
        }else if seconds == 2{
            timer.invalidate()
            //Delete Data
            if (UserDefaults.standard.object(forKey: "name") as? NSData) != nil{
                UserDefaults.standard.removeObject(forKey: "name")
                UserDefaults.standard.synchronize()
            }
            if (UserDefaults.standard.object(forKey: "target") as? Int) != nil{
                UserDefaults.standard.removeObject(forKey: "target")
                UserDefaults.standard.synchronize()
                targetAmountCount = 0
            }
            if (UserDefaults.standard.object(forKey: "current") as? Int) != nil{
                UserDefaults.standard.removeObject(forKey: "current")
                UserDefaults.standard.synchronize()
                currentMoneyCount = 0
            }
            
            let document = FileManager.default
            let path = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("drawingImage.png")
            if document.fileExists(atPath: path){
                try! document.removeItem(atPath: path)
            }else{
                
            }
            
            let OKbutton = UIButton()
            OKbutton.setImage(UIImage(named: "images/detailsView/OKbutton.png"), for: .normal)
            OKbutton.frame = CGRect(x: -11, y: 600, width: 400, height: 65)
            OKbutton.addTarget(self, action: #selector(detailsVC.okButtonAction), for: .touchUpInside)
            view.addSubview(OKbutton)
                //OK Button Animate
                let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0, 500, 0)
                OKbutton.layer.transform = rotationTransform
                UIView.animate(withDuration: 1.0) {
                    OKbutton.layer.transform = CATransform3DIdentity
                }
            
            
        }
    }
        //OK Button Action
        @objc func okButtonAction(){
            loginStatus = false
            PlaygroundPage.current.liveView = getNameViewVC()
        }
    //End
    
    func backgroundAnimate(){
        //Rotation Transforms
        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0, -500, 0)
        let rotationTransform2 = CATransform3DTranslate(CATransform3DIdentity, -500, 10, 0)
        let rotationTransform3 = CATransform3DTranslate(CATransform3DIdentity, 500, 10, 0)
        let rotationTransform4 = CATransform3DTranslate(CATransform3DIdentity, 10, -500, 0)
        let rotationTransform5 = CATransform3DTranslate(CATransform3DIdentity, 10, 500, 0)
        
        
        //Background Image Animate
        self.backImage.layer.transform = rotationTransform
        
        //Back Button Animate
        self.backButton.layer.transform = rotationTransform3
        
        //Save Button Animate
        self.deleteButton.layer.transform = rotationTransform3
        
        //Drawing View Animate
        self.CanvasView.layer.transform = rotationTransform2
        
        //Hide Image View Animate
        self.hideImageView.layer.transform = rotationTransform2
        
        //Color 1 Button Animate
        self.color1Button.layer.transform = rotationTransform2
        
        //Color 2 Button Animate
        self.color2Button.layer.transform = rotationTransform2
        
        //Color 3 Button Animate
        self.color3Button.layer.transform = rotationTransform2
        
        //Color 4 Button Animate
        self.color4Button.layer.transform = rotationTransform2
        
        //Size Background Image Animate
        self.sizeBack.layer.transform = rotationTransform3
        
        //Size 5 Button Animate
        self.size5Button.layer.transform = rotationTransform3
        
        //Size 15 Button Animate
        self.size15Button.layer.transform = rotationTransform3
        
        //Clear Button Animate
        self.clearButton.layer.transform = rotationTransform3
        
        //Picture of Dream Image Animate
        self.pictureofdreamImage.layer.transform = rotationTransform2
        
        //Logo Image Animate
        self.logoImage.layer.transform = rotationTransform4
        
        //Target Amount Header Image Animate
        self.targetHeaderImage.layer.transform = rotationTransform2
        self.targetamountImage.layer.transform = rotationTransform2
        
        //Current Money Header Image Animate
        self.currentHeaderImage.layer.transform = rotationTransform3
        self.currentmoneyImage.layer.transform = rotationTransform3
        
        //Target Amount Body Image Animate
        self.targetBodyImage.layer.transform = rotationTransform5
        self.targetAmountText.layer.transform = rotationTransform5
        
        //Current Money Body Image Animate
        self.currentBodyImage.layer.transform = rotationTransform5
        self.currentCountText.layer.transform = rotationTransform5
        
        //UIView Animate
        UIView.animate(withDuration: 1.0) {
            self.backImage.layer.transform = CATransform3DIdentity
            self.minusButton.isHidden = true
            self.plusButton.isHidden = true
            self.plusminusBack.isHidden = true
        }
        UIView.animate(withDuration: 1.5) {
            self.logoImage.layer.transform = CATransform3DIdentity
            self.plusminusBack.layer.transform = CATransform3DIdentity
            self.plusButton.layer.transform = CATransform3DIdentity
            self.minusButton.layer.transform = CATransform3DIdentity
        }
        UIView.animate(withDuration: 2.2) {
            self.backButton.layer.transform = CATransform3DIdentity
            self.deleteButton.layer.transform = CATransform3DIdentity
            self.CanvasView.layer.transform = CATransform3DIdentity
            self.hideImageView.layer.transform = CATransform3DIdentity
            self.pictureofdreamImage.layer.transform = CATransform3DIdentity
            self.color1Button.layer.transform = CATransform3DIdentity
            self.color2Button.layer.transform = CATransform3DIdentity
            self.color3Button.layer.transform = CATransform3DIdentity
            self.color4Button.layer.transform = CATransform3DIdentity
            self.sizeBack.layer.transform = CATransform3DIdentity
            self.size5Button.layer.transform = CATransform3DIdentity
            self.size15Button.layer.transform = CATransform3DIdentity
            self.clearButton.layer.transform = CATransform3DIdentity
        }
        UIView.animate(withDuration: 2.6) {
            self.targetHeaderImage.layer.transform = CATransform3DIdentity
            self.currentHeaderImage.layer.transform = CATransform3DIdentity
            self.targetamountImage.layer.transform = CATransform3DIdentity
            self.currentmoneyImage.layer.transform = CATransform3DIdentity
            self.targetBodyImage.layer.transform = CATransform3DIdentity
            self.currentBodyImage.layer.transform = CATransform3DIdentity
            self.currentCountText.layer.transform = CATransform3DIdentity
            self.targetAmountText.layer.transform = CATransform3DIdentity
        }
    }
}

