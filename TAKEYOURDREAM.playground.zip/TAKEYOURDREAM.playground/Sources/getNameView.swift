//WWDC 2019
//Think Different

import UIKit
import PlaygroundSupport
import AVFoundation


public let nextButton = UIButton()

public class getNameViewVC: UIViewController {
    
    //Objects
    let questionLabel = UIImageView(image: UIImage(named: "images/getNameView/questionLabel.png"))
    let nameTextBack = UIImageView(image: UIImage(named: "images/getNameView/nameTextBackground.png"))
    let clearButton = UIButton()
    let drawingView = handwrittingView()
    //End
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()

        
        let view = UIView()
        view.backgroundColor = UIColor(red:0.94, green:0.94, blue:0.96, alpha:1.0)
        self.view = view
        
        hideImageVisibility = false
        
        //Text to Speech
        let utterance = AVSpeechUtterance(string: "what is your dreams name")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
        utterance.rate = 0.01
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
        //End
        
        //Question Label Image
        questionLabel.contentMode = .bottom
        questionLabel.frame = CGRect(x: 33, y: 274, width: 304, height: 34)
        //End
        
        //Name Text Label Background Image
        nameTextBack.contentMode = .bottom
        nameTextBack.frame = CGRect(x: 9, y: 330, width: 357, height: 64)
        //End
        
        //Drawing View
        drawingView.backgroundColor = UIColor.white
        drawingView.frame = CGRect(x: 10, y: 318, width: 355, height: 64)
        drawingView.layer.cornerRadius = 30
        //End

        //Clear Button
        clearButton.setImage(UIImage(named: "images/getNameView/clearButton.png"), for: .normal)
        clearButton.frame = CGRect(x: 334, y: 346, width: 12, height: 15)
        clearButton.addTarget(self, action: #selector(getNameViewVC.clearAction), for: .touchUpInside)
        //End
        
        
        //Next Button Image
        nextButton.isEnabled = false
        nextButton.setImage(UIImage(named: "images/getNameView/nextButton.png"), for: .normal)
        nextButton.frame = CGRect(x: 306.6, y: 628, width: 58.4, height: 29)
        nextButton.addTarget(self, action: #selector(getNameViewVC.nextVC), for: .touchUpInside)
        //End
        
        //Add Subview
        view.addSubview(questionLabel)
        view.addSubview(nextButton)
        view.addSubview(nameTextBack)
        view.addSubview(drawingView)
        view.addSubview(clearButton)
        //End
        
        backgroundAnimate()
    }
    
    @objc func nextVC(){
        let convertedImage = UIImage.init(view: drawingView)
        nameImage = convertedImage
        PlaygroundPage.current.liveView = detailsVC()
    }
    
    @objc func clearAction(){
        drawingView.clearCanvas()
    }
    
    func backgroundAnimate(){
        let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, -500, 10, 0)
        let rotationTransform2 = CATransform3DTranslate(CATransform3DIdentity, 500, 10, 0)
        //Question Label Image Animate
        self.questionLabel.layer.transform = rotationTransform
        
        //Name Text Background Image Animate
        self.nameTextBack.layer.transform = rotationTransform2
        
        //Drawing View Animate
        self.drawingView.layer.transform = rotationTransform2
        self.clearButton.layer.transform = rotationTransform2
        
        //Next Button Image Animate
        nextButton.layer.transform = rotationTransform2
        
        UIView.animate(withDuration: 1.5) {
            self.questionLabel.layer.transform = CATransform3DIdentity
            nextButton.layer.transform = CATransform3DIdentity
            self.drawingView.layer.transform = CATransform3DIdentity
            self.nameTextBack.layer.transform = CATransform3DIdentity
        }
        UIView.animate(withDuration: 2.0) {
            self.clearButton.layer.transform = CATransform3DIdentity
        }
    }

}
