//WWDC 2019
//Think Different

import UIKit
import PlaygroundSupport
import AVFoundation

public var loginStatus = Bool()
public var daysLabel = UILabel()

public class homepageVC : UIViewController{
    
    //Objects
    let logoImage = UIImageView(image: UIImage(named: "images/homepage/logo.png"))
    let backImage = UIImageView(image:UIImage(named: "images/homepage/Background.png"))
    let tipsView = UIImageView(image: UIImage(named: "images/homepage/tipsView.png"))
    let dreamsView = UIImageView(image: UIImage(named: "images/homepage/dreamsView.png"))
    let nameImageView = UIImageView()
    let tipsLabel = UILabel()
    //End
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let view = UIView()
        view.backgroundColor = UIColor(red:0.94, green:0.94, blue:0.96, alpha:1.0)
        self.view = view
        
        hideImageVisibility = true
        
        //Save Data and Save Data Retrievals
        if daysLabel.text == nil{
            if let savedDayValue = UserDefaults.standard.object(forKey: "dayValue") as? String{
                daysLabel.text = savedDayValue
            }
        }else{
              UserDefaults.standard.set(daysLabel.text, forKey: "dayValue")
              UserDefaults.standard.synchronize()
        }
        
        if let savedImage = UserDefaults.standard.object(forKey: "name") as? NSData{
            nameImage = UIImage(data: savedImage as Data)!
        }
        
        if let imageData = nameImage.jpegData(compressionQuality: 0.5) as NSData?{
            if imageData == UserDefaults.standard.object(forKey: "name") as? NSData{
                
            }else{
                UserDefaults.standard.set(imageData, forKey: "name")
                UserDefaults.standard.synchronize()
            }
        }

        //Data Control Place
        if UserDefaults.standard.object(forKey: "name") as? NSData == nil{
            PlaygroundPage.current.liveView = getNameViewVC()
        }
        if UserDefaults.standard.object(forKey: "name") as? NSData == nil{
            loginStatus = false
        }else{
            loginStatus = true
        }
        //End
        
        //Text to Speech
        if let dayText = daysLabel.text{
            let utterance = AVSpeechUtterance(string: "left \(dayText) days to reach your dream ")
            utterance.voice = AVSpeechSynthesisVoice(language: "en-EN")
            utterance.rate = 0.1
            
            let synthesizer = AVSpeechSynthesizer()
            synthesizer.speak(utterance)
        }
        //End
        
        //Background Image
        backImage.contentMode = .bottom
        backImage.frame = CGRect(x: 0, y: 0, width: 377, height: 267)
        //End
     
        //Logo
        logoImage.contentMode = .bottom
        logoImage.frame = CGRect(x: 13, y: 9, width: 240, height: 56)
        //End
        
        //Name Image View
        nameImageView.frame = CGRect(x: 15, y: 312, width: 345, height: 56)
        nameImageView.layer.masksToBounds = true
        nameImageView.layer.cornerRadius = 30
        nameImageView.image = nameImage
        nameImageView.isUserInteractionEnabled = true
        let gesture = UITapGestureRecognizer(target: self, action: #selector(homepageVC.segue))
        nameImageView.addGestureRecognizer(gesture)
        //End
        
        //Dreams View Image
        dreamsView.frame = CGRect(x: 8, y: 325, width: 359, height: 166.53)
        //End
        
        //Days Text Label
        daysLabel.font = UIFont(name: "Futura-CondensedExtraBold", size: 55)
        daysLabel.textColor = UIColor(red:0.13, green:0.14, blue:0.29, alpha:1.0)
        daysLabel.textAlignment = .center
        daysLabel.frame = CGRect(x: 242, y: 375, width: 110, height: 74)
        //End
        
        //Tips View Background
        tipsView.contentMode = .bottom
        tipsView.frame = CGRect(x: 15, y: 615, width: 345, height: 46.45)
            //Tips View Label
            let bool = Bool.random()
            if bool == true{
                tipsLabel.text = "You should collect 5 dollars a day"
            }else{
                tipsLabel.text = "NEVER GIVE UP!"
            }
            tipsLabel.textColor = UIColor(red:0.94, green:0.63, blue:0.00, alpha:1.0)
            tipsLabel.font = UIFont(name: "Avenir-Black", size: 15)
            tipsLabel.frame = CGRect(x: 50, y: 615, width: 280, height: 25)
            tipsLabel.textAlignment = .center
        //End
        
        //Add Subview
        view.addSubview(backImage)
        view.addSubview(logoImage)
        view.addSubview(dreamsView)
        view.addSubview(nameImageView)
        view.addSubview(tipsView)
        view.addSubview(daysLabel)
        view.addSubview(tipsLabel)
        //End
        
        //Animations func
         backgroundAnimate()
    }
    
    @objc func segue(){
        PlaygroundPage.current.liveView = detailsVC()
    }
    
    func backgroundAnimate(){
        //Rotation Transforms
         let rotationTransform = CATransform3DTranslate(CATransform3DIdentity, 0, -500, 0)
         let rotationTransform2 = CATransform3DTranslate(CATransform3DIdentity, 0, 500, 0)
         let rotationTransform3 = CATransform3DTranslate(CATransform3DIdentity, -500, 0, 0)
        let rotationTransform4 = CATransform3DTranslate(CATransform3DIdentity, 500, 0, 0)
        
        //Background Image Animate
        self.backImage.layer.transform = rotationTransform
        
        //Logo Animate
        self.logoImage.layer.transform = rotationTransform
        
        //Dreams View Image Animate
        self.dreamsView.layer.transform = rotationTransform3
        daysLabel.layer.transform = rotationTransform4
        
        // Name Image View Animate
        self.nameImageView.layer.transform = rotationTransform4
        
        //tipsView Animate
        self.tipsView.layer.transform = rotationTransform2
        self.tipsLabel.layer.transform = rotationTransform2
        
        //UIView Animate
        UIView.animate(withDuration: 1.0) {
            self.backImage.layer.transform = CATransform3DIdentity
            self.tipsView.layer.transform = CATransform3DIdentity
            self.tipsLabel.layer.transform = CATransform3DIdentity
        }
        UIView.animate(withDuration: 1.5) {
            self.logoImage.layer.transform = CATransform3DIdentity
        }
        UIView.animate(withDuration: 2.0) {
            self.dreamsView.layer.transform = CATransform3DIdentity
            daysLabel.layer.transform = CATransform3DIdentity
            self.nameImageView.layer.transform = CATransform3DIdentity
        }
    }
}
