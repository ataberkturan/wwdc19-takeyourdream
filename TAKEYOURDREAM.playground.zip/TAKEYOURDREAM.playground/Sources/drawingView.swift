//WWDC 2019
//Think Different

import UIKit
import PlaygroundSupport

public class drawingView : UIView{
   
    var lineColor:UIColor!
    var lineWidht:CGFloat!
    var path:UIBezierPath!
    var touchPoint:CGPoint!
    var startingPoint:CGPoint!
    
    public func color1Button(){
        lineColor = UIColor(red:0.13, green:0.14, blue:0.29, alpha:1.0)
        self.setNeedsDisplay()
    }
    public func color2Button(){
        lineColor = UIColor(red:0.49, green:0.70, blue:0.00, alpha:1.0)
        self.setNeedsDisplay()
    }
    public func color3Button(){
        lineColor = UIColor(red:0.94, green:0.63, blue:0.00, alpha:1.0)
        self.setNeedsDisplay()
    }
    public func color4Button(){
        lineColor = UIColor.black
        self.setNeedsDisplay()
    }
    public func size5Button(){
        lineWidht = 5
        self.setNeedsDisplay()
    }
    public func size15Button(){
        lineWidht = 15
        self.setNeedsDisplay()
    }
    
   public override func layoutSubviews() {
        self.clipsToBounds = true
        self.isMultipleTouchEnabled = false
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        startingPoint = touch?.location(in: self)
        
        if lineColor == nil && lineWidht == nil{
           color4Button()
           size5Button()
        }else if lineColor == nil{
            color4Button()
        }else if lineWidht == nil{
            size5Button()
        }

    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        touchPoint = touch?.location(in: self)
        
        path = UIBezierPath()
        path.move(to: startingPoint)
        path.addLine(to: touchPoint)
        startingPoint = touchPoint
        
        drawShapeLayer()
    }
    
    func drawShapeLayer(){
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = lineWidht
        shapeLayer.fillColor = UIColor.clear.cgColor
    
        
        self.layer.addSublayer(shapeLayer)
        self.setNeedsDisplay()
        
    }
    
    public func clearCanvas(){
        path.removeAllPoints()
        self.layer.sublayers = nil
        self.setNeedsDisplay()
    }
   
}

